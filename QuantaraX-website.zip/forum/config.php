<?php
// phpBB 3.3.x auto-generated configuration file
// Do not change anything in this file!
$dbms = 'phpbb\\db\\driver\\mysqli';
$dbhost = 'sql101.byetcluster.com';
$dbport = '';
$dbname = 'if0_40120190_298';
$dbuser = '40120190_1';
$dbpasswd = '3ix8Sp@9]t';
$table_prefix = 'phpbbso_';
$phpbb_adm_relative_path = 'adm/';
$acm_type = 'phpbb\\cache\\driver\\file';

@define('PHPBB_INSTALLED', true);
@define('PHPBB_ENVIRONMENT', 'production');
// @define('DEBUG_CONTAINER', true);
