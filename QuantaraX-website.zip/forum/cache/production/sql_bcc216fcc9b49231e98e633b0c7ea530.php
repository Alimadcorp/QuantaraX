<?php exit; ?>
1765695824
SELECT forum_id FROM phpbbso_forums WHERE forum_options & 2 <> 0 LIMIT 1
6
a:0:{}